import os
def clear(): os.system('cls')